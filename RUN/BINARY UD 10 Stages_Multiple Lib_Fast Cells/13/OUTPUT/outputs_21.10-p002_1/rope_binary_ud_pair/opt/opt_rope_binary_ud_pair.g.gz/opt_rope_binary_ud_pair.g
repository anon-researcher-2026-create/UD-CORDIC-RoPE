######################################################################

# Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Wed Apr 22 18:56:36 IST 2026

# This file contains the Genus script for design:rope_binary_ud_pair

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {/home/redhatacademy19/Documents/Siddhant/gsclib045_all_v4.8/gsclib045/timing /home/redhatacademy19/Documents/Siddhant/gsclib045_all_v4.8/gsclib045_hvt/timing /home/redhatacademy19/Documents/Siddhant/gsclib045_all_v4.8/gsclib045_lvt/timing { }}
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 33 0.0 7.0} {to_generic 5 38 5 12} {first_condense 2 41 2 16} {PBS_Generic_Opt-Post 8 41 7.884447999999999 14.884447999999999} {{PBS_Generic-Postgen HBO Optimizations} 0 41 0.0 14.884447999999999} {PBS_TechMap-Start 0 42 0.0 15.883859} {{PBS_TechMap-Premap HBO Optimizations} 1 43 0.0 15.883859} {second_condense 1 44 2 19} {reify 5 49 7 26} {global_incr_map 0 49 0 27} {{PBS_Techmap-Global Mapping} 6 49 6.861547 22.745406} {{PBS_TechMap-Datapath Postmap Operations} 0 49 1.0 23.745406} {{PBS_TechMap-Postmap HBO Optimizations} 0 49 -0.005573999999999302 23.739832} {{PBS_TechMap-Postmap Clock Gating} 0 50 0.0 23.739832} {{PBS_TechMap-Postmap Cleanup} 0 50 -0.005570000000002295 23.734261999999998} {PBS_Techmap-Post_MBCI 0 50 0.0 23.734261999999998} {incr_opt 3 53 2 30} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tinfo_tstamp_file .rs_redhatacademy19.tstamp
set_db -quiet metric_enable true
set_db -quiet script_search_path { $scriptDir }
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid 9d90a343-9dbf-40d8-ba0c-d7745e464bbb
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
set_db -quiet wireload_selection none
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
define_clock -name clk -domain domain_1 -period 2000.0 -divide_period 1 -rise 0 -divide_rise 1 -fall 1 -divide_fall 2 -remove -design design:rope_binary_ud_pair port:rope_binary_ud_pair/clk
define_cost_group -design design:rope_binary_ud_pair -name clk
external_delay -accumulate -input {0.0 no_value 0.0 no_value} -clock clock:rope_binary_ud_pair/clk -name create_clock_delay_domain_1_clk_R_0 port:rope_binary_ud_pair/clk
set_db -quiet external_delay:rope_binary_ud_pair/create_clock_delay_domain_1_clk_R_0 .clock_network_latency_included true
external_delay -accumulate -input {no_value 0.0 no_value 0.0} -clock clock:rope_binary_ud_pair/clk -edge_fall -name create_clock_delay_domain_1_clk_F_0 port:rope_binary_ud_pair/clk
set_db -quiet external_delay:rope_binary_ud_pair/create_clock_delay_domain_1_clk_F_0 .clock_network_latency_included true
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2 port:rope_binary_ud_pair/rst
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_1_1 {{port:rope_binary_ud_pair/x_even[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_2_1 {{port:rope_binary_ud_pair/x_even[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_3_1 {{port:rope_binary_ud_pair/x_even[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_4_1 {{port:rope_binary_ud_pair/x_even[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_5_1 {{port:rope_binary_ud_pair/x_even[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_6_1 {{port:rope_binary_ud_pair/x_even[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_7_1 {{port:rope_binary_ud_pair/x_even[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_8_1 {{port:rope_binary_ud_pair/x_even[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_9_1 {{port:rope_binary_ud_pair/x_even[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_10_1 {{port:rope_binary_ud_pair/x_even[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_11_1 {{port:rope_binary_ud_pair/x_even[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_12_1 {{port:rope_binary_ud_pair/x_even[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_13_1 {{port:rope_binary_ud_pair/x_even[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_14_1 {{port:rope_binary_ud_pair/x_even[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_15_1 {{port:rope_binary_ud_pair/x_even[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_16_1 {{port:rope_binary_ud_pair/x_odd[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_17_1 {{port:rope_binary_ud_pair/x_odd[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_18_1 {{port:rope_binary_ud_pair/x_odd[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_19_1 {{port:rope_binary_ud_pair/x_odd[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_20_1 {{port:rope_binary_ud_pair/x_odd[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_21_1 {{port:rope_binary_ud_pair/x_odd[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_22_1 {{port:rope_binary_ud_pair/x_odd[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_23_1 {{port:rope_binary_ud_pair/x_odd[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_24_1 {{port:rope_binary_ud_pair/x_odd[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_25_1 {{port:rope_binary_ud_pair/x_odd[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_26_1 {{port:rope_binary_ud_pair/x_odd[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_27_1 {{port:rope_binary_ud_pair/x_odd[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_28_1 {{port:rope_binary_ud_pair/x_odd[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_29_1 {{port:rope_binary_ud_pair/x_odd[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_30_1 {{port:rope_binary_ud_pair/x_odd[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_31_1 {{port:rope_binary_ud_pair/ud_bits[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_32_1 {{port:rope_binary_ud_pair/ud_bits[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_33_1 {{port:rope_binary_ud_pair/ud_bits[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_34_1 {{port:rope_binary_ud_pair/ud_bits[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_35_1 {{port:rope_binary_ud_pair/ud_bits[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_36_1 {{port:rope_binary_ud_pair/ud_bits[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_37_1 {{port:rope_binary_ud_pair/ud_bits[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_38_1 {{port:rope_binary_ud_pair/ud_bits[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_39_1 {{port:rope_binary_ud_pair/ud_bits[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_2_40_1 {{port:rope_binary_ud_pair/ud_bits[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3 {{port:rope_binary_ud_pair/y_even[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_40_1 {{port:rope_binary_ud_pair/y_even[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_41_1 {{port:rope_binary_ud_pair/y_even[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_42_1 {{port:rope_binary_ud_pair/y_even[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_43_1 {{port:rope_binary_ud_pair/y_even[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_44_1 {{port:rope_binary_ud_pair/y_even[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_45_1 {{port:rope_binary_ud_pair/y_even[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_46_1 {{port:rope_binary_ud_pair/y_even[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_47_1 {{port:rope_binary_ud_pair/y_even[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_48_1 {{port:rope_binary_ud_pair/y_even[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_49_1 {{port:rope_binary_ud_pair/y_even[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_50_1 {{port:rope_binary_ud_pair/y_even[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_51_1 {{port:rope_binary_ud_pair/y_even[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_52_1 {{port:rope_binary_ud_pair/y_even[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_53_1 {{port:rope_binary_ud_pair/y_even[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_54_1 {{port:rope_binary_ud_pair/y_odd[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_55_1 {{port:rope_binary_ud_pair/y_odd[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_56_1 {{port:rope_binary_ud_pair/y_odd[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_57_1 {{port:rope_binary_ud_pair/y_odd[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_58_1 {{port:rope_binary_ud_pair/y_odd[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_59_1 {{port:rope_binary_ud_pair/y_odd[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_60_1 {{port:rope_binary_ud_pair/y_odd[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_61_1 {{port:rope_binary_ud_pair/y_odd[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_62_1 {{port:rope_binary_ud_pair/y_odd[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_63_1 {{port:rope_binary_ud_pair/y_odd[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_64_1 {{port:rope_binary_ud_pair/y_odd[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_65_1 {{port:rope_binary_ud_pair/y_odd[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_66_1 {{port:rope_binary_ud_pair/y_odd[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_67_1 {{port:rope_binary_ud_pair/y_odd[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_binary_ud_pair/clk -name rope.sdc_line_3_68_1 {{port:rope_binary_ud_pair/y_odd[0]}}
path_group -paths [specify_paths -to clock:rope_binary_ud_pair/clk]  -name clk -group cost_group:rope_binary_ud_pair/clk -user_priority -1047552
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:rope_binary_ud_pair .seq_reason_deleted_internal {{{rotator/ud_pipeline_reg[9][0]} unloaded {rotator/ud_pipeline[9][0]}} {{rotator/ud_pipeline_reg[9][1]} unloaded {rotator/ud_pipeline[9][1]}} {{rotator/ud_pipeline_reg[9][2]} unloaded {rotator/ud_pipeline[9][2]}} {{rotator/ud_pipeline_reg[9][3]} unloaded {rotator/ud_pipeline[9][3]}} {{rotator/ud_pipeline_reg[9][4]} unloaded {rotator/ud_pipeline[9][4]}} {{rotator/ud_pipeline_reg[9][5]} unloaded {rotator/ud_pipeline[9][5]}} {{rotator/ud_pipeline_reg[9][6]} unloaded {rotator/ud_pipeline[9][6]}} {{rotator/ud_pipeline_reg[9][7]} unloaded {rotator/ud_pipeline[9][7]}} {{rotator/ud_pipeline_reg[9][8]} unloaded {rotator/ud_pipeline[9][8]}} {{rotator/ud_pipeline_reg[8][0]} unloaded {rotator/ud_pipeline[8][0]}} {{rotator/ud_pipeline_reg[8][1]} unloaded {rotator/ud_pipeline[8][1]}} {{rotator/ud_pipeline_reg[8][2]} unloaded {rotator/ud_pipeline[8][2]}} {{rotator/ud_pipeline_reg[8][3]} unloaded {rotator/ud_pipeline[8][3]}} {{rotator/ud_pipeline_reg[8][4]} unloaded {rotator/ud_pipeline[8][4]}} {{rotator/ud_pipeline_reg[8][5]} unloaded {rotator/ud_pipeline[8][5]}} {{rotator/ud_pipeline_reg[8][6]} unloaded {rotator/ud_pipeline[8][6]}} {{rotator/ud_pipeline_reg[8][7]} unloaded {rotator/ud_pipeline[8][7]}} {{rotator/ud_pipeline_reg[7][0]} unloaded {rotator/ud_pipeline[7][0]}} {{rotator/ud_pipeline_reg[7][1]} unloaded {rotator/ud_pipeline[7][1]}} {{rotator/ud_pipeline_reg[7][2]} unloaded {rotator/ud_pipeline[7][2]}} {{rotator/ud_pipeline_reg[7][3]} unloaded {rotator/ud_pipeline[7][3]}} {{rotator/ud_pipeline_reg[7][4]} unloaded {rotator/ud_pipeline[7][4]}} {{rotator/ud_pipeline_reg[7][5]} unloaded {rotator/ud_pipeline[7][5]}} {{rotator/ud_pipeline_reg[7][6]} unloaded {rotator/ud_pipeline[7][6]}} {{rotator/ud_pipeline_reg[6][0]} unloaded {rotator/ud_pipeline[6][0]}} {{rotator/ud_pipeline_reg[6][1]} unloaded {rotator/ud_pipeline[6][1]}} {{rotator/ud_pipeline_reg[6][2]} unloaded {rotator/ud_pipeline[6][2]}} {{rotator/ud_pipeline_reg[6][3]} unloaded {rotator/ud_pipeline[6][3]}} {{rotator/ud_pipeline_reg[6][4]} unloaded {rotator/ud_pipeline[6][4]}} {{rotator/ud_pipeline_reg[6][5]} unloaded {rotator/ud_pipeline[6][5]}} {{rotator/ud_pipeline_reg[5][0]} unloaded {rotator/ud_pipeline[5][0]}} {{rotator/ud_pipeline_reg[5][1]} unloaded {rotator/ud_pipeline[5][1]}} {{rotator/ud_pipeline_reg[5][2]} unloaded {rotator/ud_pipeline[5][2]}} {{rotator/ud_pipeline_reg[5][3]} unloaded {rotator/ud_pipeline[5][3]}} {{rotator/ud_pipeline_reg[5][4]} unloaded {rotator/ud_pipeline[5][4]}} {{rotator/ud_pipeline_reg[4][0]} unloaded {rotator/ud_pipeline[4][0]}} {{rotator/ud_pipeline_reg[4][1]} unloaded {rotator/ud_pipeline[4][1]}} {{rotator/ud_pipeline_reg[4][2]} unloaded {rotator/ud_pipeline[4][2]}} {{rotator/ud_pipeline_reg[4][3]} unloaded {rotator/ud_pipeline[4][3]}} {{rotator/ud_pipeline_reg[3][0]} unloaded {rotator/ud_pipeline[3][0]}} {{rotator/ud_pipeline_reg[3][1]} unloaded {rotator/ud_pipeline[3][1]}} {{rotator/ud_pipeline_reg[3][2]} unloaded {rotator/ud_pipeline[3][2]}} {{rotator/ud_pipeline_reg[2][0]} unloaded {rotator/ud_pipeline[2][0]}} {{rotator/ud_pipeline_reg[2][1]} unloaded {rotator/ud_pipeline[2][1]}} {{rotator/ud_pipeline_reg[1][0]} unloaded {rotator/ud_pipeline[1][0]}}}
set_db -quiet design:rope_binary_ud_pair .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 11704} {cell_count 3765} {utilization  0.00} {runtime 5 38 5 12} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 11934} {cell_count 3511} {utilization  0.00} {runtime 2 41 2 16} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 11934} {cell_count 3511} {utilization  0.00} {runtime 1 44 2 19} }{reify {wns 1344} {tns 0} {vep 0} {area 4681} {cell_count 1286} {utilization  0.00} {runtime 5 49 7 26} }{global_incr_map {wns 1317} {tns 0} {vep 0} {area 4663} {cell_count 1286} {utilization  0.00} {runtime 0 49 0 27} }{incr_opt {wns 214748365} {tns 0} {vep 0} {area 4646} {cell_count 1271} {utilization  0.00} {runtime 3 53 2 30} }}
set_db -quiet design:rope_binary_ud_pair .seq_mbci_coverage 0.0
set_db -quiet design:rope_binary_ud_pair .hdl_user_name rope_binary_ud_pair
set_db -quiet design:rope_binary_ud_pair .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Siddhant/RTL/binary_ud_cordic_core.v /home/redhatacademy19/Documents/Siddhant/RTL/rope_binary_ud_pair.v} {$rtlDir} {}}}
set_db -quiet design:rope_binary_ud_pair .seq_reason_deleted {{{rotator/ud_pipeline_reg[9][0]} unloaded} {{rotator/ud_pipeline_reg[9][1]} unloaded} {{rotator/ud_pipeline_reg[9][2]} unloaded} {{rotator/ud_pipeline_reg[9][3]} unloaded} {{rotator/ud_pipeline_reg[9][4]} unloaded} {{rotator/ud_pipeline_reg[9][5]} unloaded} {{rotator/ud_pipeline_reg[9][6]} unloaded} {{rotator/ud_pipeline_reg[9][7]} unloaded} {{rotator/ud_pipeline_reg[9][8]} unloaded} {{rotator/ud_pipeline_reg[8][0]} unloaded} {{rotator/ud_pipeline_reg[8][1]} unloaded} {{rotator/ud_pipeline_reg[8][2]} unloaded} {{rotator/ud_pipeline_reg[8][3]} unloaded} {{rotator/ud_pipeline_reg[8][4]} unloaded} {{rotator/ud_pipeline_reg[8][5]} unloaded} {{rotator/ud_pipeline_reg[8][6]} unloaded} {{rotator/ud_pipeline_reg[8][7]} unloaded} {{rotator/ud_pipeline_reg[7][0]} unloaded} {{rotator/ud_pipeline_reg[7][1]} unloaded} {{rotator/ud_pipeline_reg[7][2]} unloaded} {{rotator/ud_pipeline_reg[7][3]} unloaded} {{rotator/ud_pipeline_reg[7][4]} unloaded} {{rotator/ud_pipeline_reg[7][5]} unloaded} {{rotator/ud_pipeline_reg[7][6]} unloaded} {{rotator/ud_pipeline_reg[6][0]} unloaded} {{rotator/ud_pipeline_reg[6][1]} unloaded} {{rotator/ud_pipeline_reg[6][2]} unloaded} {{rotator/ud_pipeline_reg[6][3]} unloaded} {{rotator/ud_pipeline_reg[6][4]} unloaded} {{rotator/ud_pipeline_reg[6][5]} unloaded} {{rotator/ud_pipeline_reg[5][0]} unloaded} {{rotator/ud_pipeline_reg[5][1]} unloaded} {{rotator/ud_pipeline_reg[5][2]} unloaded} {{rotator/ud_pipeline_reg[5][3]} unloaded} {{rotator/ud_pipeline_reg[5][4]} unloaded} {{rotator/ud_pipeline_reg[4][0]} unloaded} {{rotator/ud_pipeline_reg[4][1]} unloaded} {{rotator/ud_pipeline_reg[4][2]} unloaded} {{rotator/ud_pipeline_reg[4][3]} unloaded} {{rotator/ud_pipeline_reg[3][0]} unloaded} {{rotator/ud_pipeline_reg[3][1]} unloaded} {{rotator/ud_pipeline_reg[3][2]} unloaded} {{rotator/ud_pipeline_reg[2][0]} unloaded} {{rotator/ud_pipeline_reg[2][1]} unloaded} {{rotator/ud_pipeline_reg[1][0]} unloaded}}
set_db -quiet design:rope_binary_ud_pair .verification_directory fv/rope_binary_ud_pair
set_db -quiet design:rope_binary_ud_pair .lp_clock_gating_max_flops inf
set_db -quiet design:rope_binary_ud_pair .arch_filename /home/redhatacademy19/Documents/Siddhant/RTL/rope_binary_ud_pair.v
set_db -quiet design:rope_binary_ud_pair .entity_filename /home/redhatacademy19/Documents/Siddhant/RTL/rope_binary_ud_pair.v
set_db -quiet port:rope_binary_ud_pair/clk .original_name clk
set_db -quiet port:rope_binary_ud_pair/rst .original_name rst
set_db -quiet {port:rope_binary_ud_pair/x_even[14]} .original_name {x_even[14]}
set_db -quiet {port:rope_binary_ud_pair/x_even[13]} .original_name {x_even[13]}
set_db -quiet {port:rope_binary_ud_pair/x_even[12]} .original_name {x_even[12]}
set_db -quiet {port:rope_binary_ud_pair/x_even[11]} .original_name {x_even[11]}
set_db -quiet {port:rope_binary_ud_pair/x_even[10]} .original_name {x_even[10]}
set_db -quiet {port:rope_binary_ud_pair/x_even[9]} .original_name {x_even[9]}
set_db -quiet {port:rope_binary_ud_pair/x_even[8]} .original_name {x_even[8]}
set_db -quiet {port:rope_binary_ud_pair/x_even[7]} .original_name {x_even[7]}
set_db -quiet {port:rope_binary_ud_pair/x_even[6]} .original_name {x_even[6]}
set_db -quiet {port:rope_binary_ud_pair/x_even[5]} .original_name {x_even[5]}
set_db -quiet {port:rope_binary_ud_pair/x_even[4]} .original_name {x_even[4]}
set_db -quiet {port:rope_binary_ud_pair/x_even[3]} .original_name {x_even[3]}
set_db -quiet {port:rope_binary_ud_pair/x_even[2]} .original_name {x_even[2]}
set_db -quiet {port:rope_binary_ud_pair/x_even[1]} .original_name {x_even[1]}
set_db -quiet {port:rope_binary_ud_pair/x_even[0]} .original_name {x_even[0]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[14]} .original_name {x_odd[14]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[13]} .original_name {x_odd[13]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[12]} .original_name {x_odd[12]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[11]} .original_name {x_odd[11]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[10]} .original_name {x_odd[10]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[9]} .original_name {x_odd[9]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[8]} .original_name {x_odd[8]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[7]} .original_name {x_odd[7]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[6]} .original_name {x_odd[6]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[5]} .original_name {x_odd[5]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[4]} .original_name {x_odd[4]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[3]} .original_name {x_odd[3]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[2]} .original_name {x_odd[2]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[1]} .original_name {x_odd[1]}
set_db -quiet {port:rope_binary_ud_pair/x_odd[0]} .original_name {x_odd[0]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[9]} .original_name {ud_bits[9]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[8]} .original_name {ud_bits[8]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[7]} .original_name {ud_bits[7]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[6]} .original_name {ud_bits[6]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[5]} .original_name {ud_bits[5]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[4]} .original_name {ud_bits[4]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[3]} .original_name {ud_bits[3]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[2]} .original_name {ud_bits[2]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[1]} .original_name {ud_bits[1]}
set_db -quiet {port:rope_binary_ud_pair/ud_bits[0]} .original_name {ud_bits[0]}
set_db -quiet {port:rope_binary_ud_pair/y_even[14]} .original_name {y_even[14]}
set_db -quiet {port:rope_binary_ud_pair/y_even[13]} .original_name {y_even[13]}
set_db -quiet {port:rope_binary_ud_pair/y_even[12]} .original_name {y_even[12]}
set_db -quiet {port:rope_binary_ud_pair/y_even[11]} .original_name {y_even[11]}
set_db -quiet {port:rope_binary_ud_pair/y_even[10]} .original_name {y_even[10]}
set_db -quiet {port:rope_binary_ud_pair/y_even[9]} .original_name {y_even[9]}
set_db -quiet {port:rope_binary_ud_pair/y_even[8]} .original_name {y_even[8]}
set_db -quiet {port:rope_binary_ud_pair/y_even[7]} .original_name {y_even[7]}
set_db -quiet {port:rope_binary_ud_pair/y_even[6]} .original_name {y_even[6]}
set_db -quiet {port:rope_binary_ud_pair/y_even[5]} .original_name {y_even[5]}
set_db -quiet {port:rope_binary_ud_pair/y_even[4]} .original_name {y_even[4]}
set_db -quiet {port:rope_binary_ud_pair/y_even[3]} .original_name {y_even[3]}
set_db -quiet {port:rope_binary_ud_pair/y_even[2]} .original_name {y_even[2]}
set_db -quiet {port:rope_binary_ud_pair/y_even[1]} .original_name {y_even[1]}
set_db -quiet {port:rope_binary_ud_pair/y_even[0]} .original_name {y_even[0]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[14]} .original_name {y_odd[14]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[13]} .original_name {y_odd[13]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[12]} .original_name {y_odd[12]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[11]} .original_name {y_odd[11]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[10]} .original_name {y_odd[10]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[9]} .original_name {y_odd[9]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[8]} .original_name {y_odd[8]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[7]} .original_name {y_odd[7]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[6]} .original_name {y_odd[6]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[5]} .original_name {y_odd[5]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[4]} .original_name {y_odd[4]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[3]} .original_name {y_odd[3]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[2]} .original_name {y_odd[2]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[1]} .original_name {y_odd[1]}
set_db -quiet {port:rope_binary_ud_pair/y_odd[0]} .original_name {y_odd[0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][9]} .original_name {{rotator/ud_pipeline[8][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][9]} .single_bit_orig_name {rotator/ud_pipeline[8][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][9]/Q} .original_name {rotator/ud_pipeline[8][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][9]} .original_name {{rotator/ud_pipeline[7][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][9]} .single_bit_orig_name {rotator/ud_pipeline[7][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][9]/Q} .original_name {rotator/ud_pipeline[7][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][9]} .original_name {{rotator/ud_pipeline[6][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][9]} .single_bit_orig_name {rotator/ud_pipeline[6][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][9]/Q} .original_name {rotator/ud_pipeline[6][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][9]} .original_name {{rotator/ud_pipeline[5][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][9]} .single_bit_orig_name {rotator/ud_pipeline[5][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][9]/Q} .original_name {rotator/ud_pipeline[5][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][9]} .original_name {{rotator/ud_pipeline[4][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][9]} .single_bit_orig_name {rotator/ud_pipeline[4][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][9]/Q} .original_name {rotator/ud_pipeline[4][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][9]} .original_name {{rotator/ud_pipeline[3][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][9]} .single_bit_orig_name {rotator/ud_pipeline[3][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][9]/Q} .original_name {rotator/ud_pipeline[3][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][9]} .original_name {{rotator/ud_pipeline[2][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][9]} .single_bit_orig_name {rotator/ud_pipeline[2][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][9]/Q} .original_name {rotator/ud_pipeline[2][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][9]} .original_name {{rotator/ud_pipeline[1][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][9]} .single_bit_orig_name {rotator/ud_pipeline[1][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][9]/Q} .original_name {rotator/ud_pipeline[1][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][9]} .original_name {{rotator/ud_pipeline[0][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][9]} .single_bit_orig_name {rotator/ud_pipeline[0][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][9]/Q} .original_name {rotator/ud_pipeline[0][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][14]} .original_name {{rotator/y[0][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][14]} .single_bit_orig_name {rotator/y[0][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][14]/Q} .original_name {rotator/y[0][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][7]} .original_name {{rotator/y[0][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][7]} .single_bit_orig_name {rotator/y[0][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][7]/Q} .original_name {rotator/y[0][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][11]} .original_name {{rotator/y[0][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][11]} .single_bit_orig_name {rotator/y[0][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][11]/Q} .original_name {rotator/y[0][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][12]} .original_name {{rotator/x[0][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][12]} .single_bit_orig_name {rotator/x[0][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][12]/Q} .original_name {rotator/x[0][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][13]} .original_name {{rotator/y[0][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][13]} .single_bit_orig_name {rotator/y[0][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][13]/Q} .original_name {rotator/y[0][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][11]} .original_name {{rotator/x[0][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][11]} .single_bit_orig_name {rotator/x[0][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][11]/Q} .original_name {rotator/x[0][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][6]} .original_name {{rotator/y[0][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][6]} .single_bit_orig_name {rotator/y[0][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][6]/Q} .original_name {rotator/y[0][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][13]} .original_name {{rotator/x[0][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][13]} .single_bit_orig_name {rotator/x[0][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][13]/Q} .original_name {rotator/x[0][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][10]} .original_name {{rotator/x[0][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][10]} .single_bit_orig_name {rotator/x[0][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][10]/Q} .original_name {rotator/x[0][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][9]} .original_name {{rotator/x[0][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][9]} .single_bit_orig_name {rotator/x[0][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][9]/Q} .original_name {rotator/x[0][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][5]} .original_name {{rotator/y[0][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][5]} .single_bit_orig_name {rotator/y[0][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][5]/Q} .original_name {rotator/y[0][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][10]} .original_name {{rotator/y[0][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][10]} .single_bit_orig_name {rotator/y[0][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][10]/Q} .original_name {rotator/y[0][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][8]} .original_name {{rotator/x[0][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][8]} .single_bit_orig_name {rotator/x[0][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][8]/Q} .original_name {rotator/x[0][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][7]} .original_name {{rotator/x[0][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][7]} .single_bit_orig_name {rotator/x[0][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][7]/Q} .original_name {rotator/x[0][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][4]} .original_name {{rotator/y[0][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][4]} .single_bit_orig_name {rotator/y[0][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][4]/Q} .original_name {rotator/y[0][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][0]} .original_name {{rotator/x[0][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][0]} .single_bit_orig_name {rotator/x[0][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][0]/Q} .original_name {rotator/x[0][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][0]} .original_name {{rotator/y[0][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][0]} .single_bit_orig_name {rotator/y[0][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][0]/Q} .original_name {rotator/y[0][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][5]} .original_name {{rotator/x[0][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][5]} .single_bit_orig_name {rotator/x[0][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][5]/Q} .original_name {rotator/x[0][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][3]} .original_name {{rotator/y[0][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][3]} .single_bit_orig_name {rotator/y[0][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][3]/Q} .original_name {rotator/y[0][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][9]} .original_name {{rotator/y[0][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][9]} .single_bit_orig_name {rotator/y[0][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][9]/Q} .original_name {rotator/y[0][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][4]} .original_name {{rotator/x[0][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][4]} .single_bit_orig_name {rotator/x[0][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][4]/Q} .original_name {rotator/x[0][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][12]} .original_name {{rotator/y[0][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][12]} .single_bit_orig_name {rotator/y[0][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][12]/Q} .original_name {rotator/y[0][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][3]} .original_name {{rotator/x[0][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][3]} .single_bit_orig_name {rotator/x[0][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][3]/Q} .original_name {rotator/x[0][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][2]} .original_name {{rotator/y[0][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][2]} .single_bit_orig_name {rotator/y[0][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][2]/Q} .original_name {rotator/y[0][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][14]} .original_name {{rotator/x[0][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][14]} .single_bit_orig_name {rotator/x[0][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][14]/Q} .original_name {rotator/x[0][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][2]} .original_name {{rotator/x[0][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][2]} .single_bit_orig_name {rotator/x[0][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][2]/Q} .original_name {rotator/x[0][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][1]} .original_name {{rotator/x[0][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][1]} .single_bit_orig_name {rotator/x[0][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][1]/Q} .original_name {rotator/x[0][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][1]} .original_name {{rotator/y[0][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][1]} .single_bit_orig_name {rotator/y[0][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][1]/Q} .original_name {rotator/y[0][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][8]} .original_name {{rotator/y[0][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][8]} .single_bit_orig_name {rotator/y[0][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[0][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[0][8]/Q} .original_name {rotator/y[0][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][6]} .original_name {{rotator/x[0][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][6]} .single_bit_orig_name {rotator/x[0][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[0][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[0][6]/Q} .original_name {rotator/x[0][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][0]} .original_name {{rotator/ud_pipeline[0][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][0]} .single_bit_orig_name {rotator/ud_pipeline[0][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][0]/Q} .original_name {rotator/ud_pipeline[0][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][5]} .original_name {{rotator/y[10][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][5]} .single_bit_orig_name {rotator/y[10][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][5]/Q} .original_name {rotator/y[10][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][13]} .original_name {{rotator/y[10][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][13]} .single_bit_orig_name {rotator/y[10][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][13]/Q} .original_name {rotator/y[10][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][11]} .original_name {{rotator/y[10][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][11]} .single_bit_orig_name {rotator/y[10][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][11]/Q} .original_name {rotator/y[10][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][7]} .original_name {{rotator/y[10][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][7]} .single_bit_orig_name {rotator/y[10][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][7]/Q} .original_name {rotator/y[10][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][6]} .original_name {{rotator/y[10][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][6]} .single_bit_orig_name {rotator/y[10][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][6]/Q} .original_name {rotator/y[10][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][10]} .original_name {{rotator/y[10][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][10]} .single_bit_orig_name {rotator/y[10][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][10]/Q} .original_name {rotator/y[10][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][14]} .original_name {{rotator/y[10][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][14]} .single_bit_orig_name {rotator/y[10][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][14]/Q} .original_name {rotator/y[10][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][2]} .original_name {{rotator/y[10][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][2]} .single_bit_orig_name {rotator/y[10][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][2]/Q} .original_name {rotator/y[10][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][12]} .original_name {{rotator/y[10][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][12]} .single_bit_orig_name {rotator/y[10][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][12]/Q} .original_name {rotator/y[10][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][9]} .original_name {{rotator/y[10][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][9]} .single_bit_orig_name {rotator/y[10][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][9]/Q} .original_name {rotator/y[10][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][3]} .original_name {{rotator/y[10][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][3]} .single_bit_orig_name {rotator/y[10][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][3]/Q} .original_name {rotator/y[10][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][4]} .original_name {{rotator/y[10][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][4]} .single_bit_orig_name {rotator/y[10][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][4]/Q} .original_name {rotator/y[10][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][8]} .original_name {{rotator/y[10][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][8]} .single_bit_orig_name {rotator/y[10][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][8]/Q} .original_name {rotator/y[10][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][1]} .original_name {{rotator/y[10][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][1]} .single_bit_orig_name {rotator/y[10][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][1]/Q} .original_name {rotator/y[10][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][0]} .original_name {{rotator/y[10][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][0]} .single_bit_orig_name {rotator/y[10][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[10][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[10][0]/Q} .original_name {rotator/y[10][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][1]} .original_name {{rotator/ud_pipeline[1][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][1]} .single_bit_orig_name {rotator/ud_pipeline[1][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][1]/Q} .original_name {rotator/ud_pipeline[1][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][1]} .original_name {{rotator/ud_pipeline[0][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][1]} .single_bit_orig_name {rotator/ud_pipeline[0][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][1]/Q} .original_name {rotator/ud_pipeline[0][1]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][1]/QN} .original_name {rotator/ud_pipeline[0][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][7]} .original_name {{rotator/x[1][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][7]} .single_bit_orig_name {rotator/x[1][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][7]/Q} .original_name {rotator/x[1][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][11]} .original_name {{rotator/x[1][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][11]} .single_bit_orig_name {rotator/x[1][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][11]/Q} .original_name {rotator/x[1][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][11]} .original_name {{rotator/y[1][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][11]} .single_bit_orig_name {rotator/y[1][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][11]/Q} .original_name {rotator/y[1][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][13]} .original_name {{rotator/x[1][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][13]} .single_bit_orig_name {rotator/x[1][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][13]/Q} .original_name {rotator/x[1][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][10]} .original_name {{rotator/y[1][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][10]} .single_bit_orig_name {rotator/y[1][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][10]/Q} .original_name {rotator/y[1][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][6]} .original_name {{rotator/x[1][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][6]} .single_bit_orig_name {rotator/x[1][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][6]/Q} .original_name {rotator/x[1][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][12]} .original_name {{rotator/y[1][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][12]} .single_bit_orig_name {rotator/y[1][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][12]/Q} .original_name {rotator/y[1][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][14]} .original_name {{rotator/x[1][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][14]} .single_bit_orig_name {rotator/x[1][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][14]/Q} .original_name {rotator/x[1][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][8]} .original_name {{rotator/y[1][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][8]} .single_bit_orig_name {rotator/y[1][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][8]/Q} .original_name {rotator/y[1][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][9]} .original_name {{rotator/y[1][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][9]} .single_bit_orig_name {rotator/y[1][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][9]/Q} .original_name {rotator/y[1][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][5]} .original_name {{rotator/x[1][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][5]} .single_bit_orig_name {rotator/x[1][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][5]/Q} .original_name {rotator/x[1][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][10]} .original_name {{rotator/x[1][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][10]} .single_bit_orig_name {rotator/x[1][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][10]/Q} .original_name {rotator/x[1][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][7]} .original_name {{rotator/y[1][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][7]} .single_bit_orig_name {rotator/y[1][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][7]/Q} .original_name {rotator/y[1][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][6]} .original_name {{rotator/y[1][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][6]} .single_bit_orig_name {rotator/y[1][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][6]/Q} .original_name {rotator/y[1][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][1]} .original_name {{rotator/y[1][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][1]} .single_bit_orig_name {rotator/y[1][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][1]/Q} .original_name {rotator/y[1][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][0]} .original_name {{rotator/x[1][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][0]} .single_bit_orig_name {rotator/x[1][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][0]/Q} .original_name {rotator/x[1][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][1]} .original_name {{rotator/x[1][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][1]} .single_bit_orig_name {rotator/x[1][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][1]/Q} .original_name {rotator/x[1][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][0]} .original_name {{rotator/y[1][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][0]} .single_bit_orig_name {rotator/y[1][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][0]/Q} .original_name {rotator/y[1][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][9]} .original_name {{rotator/x[1][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][9]} .single_bit_orig_name {rotator/x[1][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][9]/Q} .original_name {rotator/x[1][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][3]} .original_name {{rotator/y[1][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][3]} .single_bit_orig_name {rotator/y[1][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][3]/Q} .original_name {rotator/y[1][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][13]} .original_name {{rotator/y[1][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][13]} .single_bit_orig_name {rotator/y[1][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][13]/Q} .original_name {rotator/y[1][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][12]} .original_name {{rotator/x[1][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][12]} .single_bit_orig_name {rotator/x[1][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][12]/Q} .original_name {rotator/x[1][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][2]} .original_name {{rotator/y[1][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][2]} .single_bit_orig_name {rotator/y[1][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][2]/Q} .original_name {rotator/y[1][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][2]} .original_name {{rotator/x[1][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][2]} .single_bit_orig_name {rotator/x[1][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][2]/Q} .original_name {rotator/x[1][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][5]} .original_name {{rotator/y[1][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][5]} .single_bit_orig_name {rotator/y[1][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][5]/Q} .original_name {rotator/y[1][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][4]} .original_name {{rotator/y[1][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][4]} .single_bit_orig_name {rotator/y[1][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][4]/Q} .original_name {rotator/y[1][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][3]} .original_name {{rotator/x[1][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][3]} .single_bit_orig_name {rotator/x[1][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][3]/Q} .original_name {rotator/x[1][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][14]} .original_name {{rotator/y[1][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][14]} .single_bit_orig_name {rotator/y[1][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[1][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[1][14]/Q} .original_name {rotator/y[1][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][8]} .original_name {{rotator/x[1][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][8]} .single_bit_orig_name {rotator/x[1][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][8]/Q} .original_name {rotator/x[1][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][4]} .original_name {{rotator/x[1][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][4]} .single_bit_orig_name {rotator/x[1][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[1][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[1][4]/Q} .original_name {rotator/x[1][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][2]} .original_name {{rotator/ud_pipeline[2][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][2]} .single_bit_orig_name {rotator/ud_pipeline[2][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][2]/Q} .original_name {rotator/ud_pipeline[2][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][2]} .original_name {{rotator/ud_pipeline[1][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][2]} .single_bit_orig_name {rotator/ud_pipeline[1][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][2]/Q} .original_name {rotator/ud_pipeline[1][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][0]} .original_name {{rotator/x[2][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][0]} .single_bit_orig_name {rotator/x[2][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][0]/Q} .original_name {rotator/x[2][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][11]} .original_name {{rotator/y[2][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][11]} .single_bit_orig_name {rotator/y[2][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][11]/Q} .original_name {rotator/y[2][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][7]} .original_name {{rotator/x[2][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][7]} .single_bit_orig_name {rotator/x[2][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][7]/Q} .original_name {rotator/x[2][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][11]} .original_name {{rotator/x[2][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][11]} .single_bit_orig_name {rotator/x[2][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][11]/Q} .original_name {rotator/x[2][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][10]} .original_name {{rotator/y[2][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][10]} .single_bit_orig_name {rotator/y[2][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][10]/Q} .original_name {rotator/y[2][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][13]} .original_name {{rotator/x[2][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][13]} .single_bit_orig_name {rotator/x[2][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][13]/Q} .original_name {rotator/x[2][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][9]} .original_name {{rotator/y[2][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][9]} .single_bit_orig_name {rotator/y[2][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][9]/Q} .original_name {rotator/y[2][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][6]} .original_name {{rotator/x[2][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][6]} .single_bit_orig_name {rotator/x[2][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][6]/Q} .original_name {rotator/x[2][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][8]} .original_name {{rotator/y[2][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][8]} .single_bit_orig_name {rotator/y[2][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][8]/Q} .original_name {rotator/y[2][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][14]} .original_name {{rotator/x[2][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][14]} .single_bit_orig_name {rotator/x[2][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][14]/Q} .original_name {rotator/x[2][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][7]} .original_name {{rotator/y[2][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][7]} .single_bit_orig_name {rotator/y[2][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][7]/Q} .original_name {rotator/y[2][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][5]} .original_name {{rotator/x[2][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][5]} .single_bit_orig_name {rotator/x[2][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][5]/Q} .original_name {rotator/x[2][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][10]} .original_name {{rotator/x[2][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][10]} .single_bit_orig_name {rotator/x[2][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][10]/Q} .original_name {rotator/x[2][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][6]} .original_name {{rotator/y[2][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][6]} .single_bit_orig_name {rotator/y[2][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][6]/Q} .original_name {rotator/y[2][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][5]} .original_name {{rotator/y[2][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][5]} .single_bit_orig_name {rotator/y[2][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][5]/Q} .original_name {rotator/y[2][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][2]} .original_name {{rotator/ud_pipeline[0][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][2]} .single_bit_orig_name {rotator/ud_pipeline[0][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][2]/Q} .original_name {rotator/ud_pipeline[0][2]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][2]/QN} .original_name {rotator/ud_pipeline[0][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][2]} .original_name {{rotator/x[2][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][2]} .single_bit_orig_name {rotator/x[2][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][2]/Q} .original_name {rotator/x[2][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][1]} .original_name {{rotator/x[2][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][1]} .single_bit_orig_name {rotator/x[2][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][1]/Q} .original_name {rotator/x[2][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][2]} .original_name {{rotator/y[2][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][2]} .single_bit_orig_name {rotator/y[2][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][2]/Q} .original_name {rotator/y[2][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][0]} .original_name {{rotator/y[2][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][0]} .single_bit_orig_name {rotator/y[2][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][0]/Q} .original_name {rotator/y[2][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][1]} .original_name {{rotator/y[2][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][1]} .single_bit_orig_name {rotator/y[2][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][1]/Q} .original_name {rotator/y[2][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][9]} .original_name {{rotator/x[2][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][9]} .single_bit_orig_name {rotator/x[2][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][9]/Q} .original_name {rotator/x[2][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][4]} .original_name {{rotator/y[2][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][4]} .single_bit_orig_name {rotator/y[2][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][4]/Q} .original_name {rotator/y[2][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][3]} .original_name {{rotator/y[2][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][3]} .single_bit_orig_name {rotator/y[2][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][3]/Q} .original_name {rotator/y[2][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][12]} .original_name {{rotator/x[2][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][12]} .single_bit_orig_name {rotator/x[2][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][12]/Q} .original_name {rotator/x[2][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][3]} .original_name {{rotator/x[2][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][3]} .single_bit_orig_name {rotator/x[2][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][3]/Q} .original_name {rotator/x[2][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][14]} .original_name {{rotator/y[2][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][14]} .single_bit_orig_name {rotator/y[2][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][14]/Q} .original_name {rotator/y[2][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][12]} .original_name {{rotator/y[2][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][12]} .single_bit_orig_name {rotator/y[2][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][12]/Q} .original_name {rotator/y[2][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][13]} .original_name {{rotator/y[2][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][13]} .single_bit_orig_name {rotator/y[2][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[2][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[2][13]/Q} .original_name {rotator/y[2][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][8]} .original_name {{rotator/x[2][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][8]} .single_bit_orig_name {rotator/x[2][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][8]/Q} .original_name {rotator/x[2][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][4]} .original_name {{rotator/x[2][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][4]} .single_bit_orig_name {rotator/x[2][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[2][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[2][4]/Q} .original_name {rotator/x[2][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][3]} .original_name {{rotator/ud_pipeline[3][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][3]} .single_bit_orig_name {rotator/ud_pipeline[3][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][3]/Q} .original_name {rotator/ud_pipeline[3][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][3]} .original_name {{rotator/ud_pipeline[2][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][3]} .single_bit_orig_name {rotator/ud_pipeline[2][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][3]/Q} .original_name {rotator/ud_pipeline[2][3]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][3]/QN} .original_name {rotator/ud_pipeline[2][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][3]} .original_name {{rotator/ud_pipeline[1][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][3]} .single_bit_orig_name {rotator/ud_pipeline[1][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][3]/Q} .original_name {rotator/ud_pipeline[1][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][3]} .original_name {{rotator/y[3][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][3]} .single_bit_orig_name {rotator/y[3][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][3]/Q} .original_name {rotator/y[3][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][3]} .original_name {{rotator/x[3][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][3]} .single_bit_orig_name {rotator/x[3][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][3]/Q} .original_name {rotator/x[3][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][6]} .original_name {{rotator/x[3][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][6]} .single_bit_orig_name {rotator/x[3][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][6]/Q} .original_name {rotator/x[3][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][9]} .original_name {{rotator/y[3][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][9]} .single_bit_orig_name {rotator/y[3][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][9]/Q} .original_name {rotator/y[3][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][13]} .original_name {{rotator/x[3][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][13]} .single_bit_orig_name {rotator/x[3][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][13]/Q} .original_name {rotator/x[3][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][8]} .original_name {{rotator/y[3][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][8]} .single_bit_orig_name {rotator/y[3][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][8]/Q} .original_name {rotator/y[3][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][7]} .original_name {{rotator/x[3][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][7]} .single_bit_orig_name {rotator/x[3][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][7]/Q} .original_name {rotator/x[3][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][10]} .original_name {{rotator/y[3][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][10]} .single_bit_orig_name {rotator/y[3][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][10]/Q} .original_name {rotator/y[3][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][7]} .original_name {{rotator/y[3][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][7]} .single_bit_orig_name {rotator/y[3][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][7]/Q} .original_name {rotator/y[3][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][14]} .original_name {{rotator/x[3][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][14]} .single_bit_orig_name {rotator/x[3][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][14]/Q} .original_name {rotator/x[3][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][6]} .original_name {{rotator/y[3][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][6]} .single_bit_orig_name {rotator/y[3][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][6]/Q} .original_name {rotator/y[3][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][5]} .original_name {{rotator/x[3][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][5]} .single_bit_orig_name {rotator/x[3][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][5]/Q} .original_name {rotator/x[3][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][10]} .original_name {{rotator/x[3][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][10]} .single_bit_orig_name {rotator/x[3][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][10]/Q} .original_name {rotator/x[3][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][5]} .original_name {{rotator/y[3][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][5]} .single_bit_orig_name {rotator/y[3][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][5]/Q} .original_name {rotator/y[3][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][4]} .original_name {{rotator/y[3][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][4]} .single_bit_orig_name {rotator/y[3][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][4]/Q} .original_name {rotator/y[3][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][3]} .original_name {{rotator/ud_pipeline[0][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][3]} .single_bit_orig_name {rotator/ud_pipeline[0][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][3]/Q} .original_name {rotator/ud_pipeline[0][3]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][3]/QN} .original_name {rotator/ud_pipeline[0][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][1]} .original_name {{rotator/x[3][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][1]} .single_bit_orig_name {rotator/x[3][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][1]/Q} .original_name {rotator/x[3][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][0]} .original_name {{rotator/x[3][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][0]} .single_bit_orig_name {rotator/x[3][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][0]/Q} .original_name {rotator/x[3][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][2]} .original_name {{rotator/y[3][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][2]} .single_bit_orig_name {rotator/y[3][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][2]/Q} .original_name {rotator/y[3][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][1]} .original_name {{rotator/y[3][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][1]} .single_bit_orig_name {rotator/y[3][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][1]/Q} .original_name {rotator/y[3][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][0]} .original_name {{rotator/y[3][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][0]} .single_bit_orig_name {rotator/y[3][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][0]/Q} .original_name {rotator/y[3][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][2]} .original_name {{rotator/x[3][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][2]} .single_bit_orig_name {rotator/x[3][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][2]/Q} .original_name {rotator/x[3][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][14]} .original_name {{rotator/y[3][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][14]} .single_bit_orig_name {rotator/y[3][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][14]/Q} .original_name {rotator/y[3][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][4]} .original_name {{rotator/x[3][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][4]} .single_bit_orig_name {rotator/x[3][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][4]/Q} .original_name {rotator/x[3][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][9]} .original_name {{rotator/x[3][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][9]} .single_bit_orig_name {rotator/x[3][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][9]/Q} .original_name {rotator/x[3][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][12]} .original_name {{rotator/x[3][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][12]} .single_bit_orig_name {rotator/x[3][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][12]/Q} .original_name {rotator/x[3][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][13]} .original_name {{rotator/y[3][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][13]} .single_bit_orig_name {rotator/y[3][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][13]/Q} .original_name {rotator/y[3][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][11]} .original_name {{rotator/y[3][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][11]} .single_bit_orig_name {rotator/y[3][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][11]/Q} .original_name {rotator/y[3][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][12]} .original_name {{rotator/y[3][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][12]} .single_bit_orig_name {rotator/y[3][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[3][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[3][12]/Q} .original_name {rotator/y[3][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][8]} .original_name {{rotator/x[3][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][8]} .single_bit_orig_name {rotator/x[3][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][8]/Q} .original_name {rotator/x[3][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][11]} .original_name {{rotator/x[3][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][11]} .single_bit_orig_name {rotator/x[3][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[3][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[3][11]/Q} .original_name {rotator/x[3][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][4]} .original_name {{rotator/ud_pipeline[4][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][4]} .single_bit_orig_name {rotator/ud_pipeline[4][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][4]/Q} .original_name {rotator/ud_pipeline[4][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][4]} .original_name {{rotator/ud_pipeline[3][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][4]} .single_bit_orig_name {rotator/ud_pipeline[3][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][4]/Q} .original_name {rotator/ud_pipeline[3][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][4]} .original_name {{rotator/ud_pipeline[2][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][4]} .single_bit_orig_name {rotator/ud_pipeline[2][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][4]/Q} .original_name {rotator/ud_pipeline[2][4]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][4]/QN} .original_name {rotator/ud_pipeline[2][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][4]} .original_name {{rotator/ud_pipeline[1][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][4]} .single_bit_orig_name {rotator/ud_pipeline[1][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][4]/Q} .original_name {rotator/ud_pipeline[1][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][2]} .original_name {{rotator/y[4][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][2]} .single_bit_orig_name {rotator/y[4][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][2]/Q} .original_name {rotator/y[4][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][3]} .original_name {{rotator/x[4][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][3]} .single_bit_orig_name {rotator/x[4][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][3]/Q} .original_name {rotator/x[4][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][4]} .original_name {{rotator/x[4][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][4]} .single_bit_orig_name {rotator/x[4][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][4]/Q} .original_name {rotator/x[4][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][0]} .original_name {{rotator/x[4][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][0]} .single_bit_orig_name {rotator/x[4][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][0]/Q} .original_name {rotator/x[4][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][1]} .original_name {{rotator/y[4][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][1]} .single_bit_orig_name {rotator/y[4][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][1]/Q} .original_name {rotator/y[4][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][6]} .original_name {{rotator/y[4][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][6]} .single_bit_orig_name {rotator/y[4][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][6]/Q} .original_name {rotator/y[4][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][11]} .original_name {{rotator/x[4][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][11]} .single_bit_orig_name {rotator/x[4][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][11]/Q} .original_name {rotator/x[4][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][14]} .original_name {{rotator/x[4][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][14]} .single_bit_orig_name {rotator/x[4][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][14]/Q} .original_name {rotator/x[4][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][5]} .original_name {{rotator/y[4][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][5]} .single_bit_orig_name {rotator/y[4][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][5]/Q} .original_name {rotator/y[4][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][6]} .original_name {{rotator/x[4][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][6]} .single_bit_orig_name {rotator/x[4][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][6]/Q} .original_name {rotator/x[4][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][5]} .original_name {{rotator/x[4][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][5]} .single_bit_orig_name {rotator/x[4][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][5]/Q} .original_name {rotator/x[4][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][7]} .original_name {{rotator/y[4][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][7]} .single_bit_orig_name {rotator/y[4][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][7]/Q} .original_name {rotator/y[4][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][10]} .original_name {{rotator/x[4][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][10]} .single_bit_orig_name {rotator/x[4][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][10]/Q} .original_name {rotator/x[4][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][13]} .original_name {{rotator/x[4][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][13]} .single_bit_orig_name {rotator/x[4][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][13]/Q} .original_name {rotator/x[4][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][8]} .original_name {{rotator/y[4][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][8]} .single_bit_orig_name {rotator/y[4][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][8]/Q} .original_name {rotator/y[4][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][4]} .original_name {{rotator/ud_pipeline[0][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][4]} .single_bit_orig_name {rotator/ud_pipeline[0][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][4]/Q} .original_name {rotator/ud_pipeline[0][4]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][4]/QN} .original_name {rotator/ud_pipeline[0][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][1]} .original_name {{rotator/x[4][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][1]} .single_bit_orig_name {rotator/x[4][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][1]/Q} .original_name {rotator/x[4][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][4]} .original_name {{rotator/y[4][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][4]} .single_bit_orig_name {rotator/y[4][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][4]/Q} .original_name {rotator/y[4][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][3]} .original_name {{rotator/y[4][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][3]} .single_bit_orig_name {rotator/y[4][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][3]/Q} .original_name {rotator/y[4][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][2]} .original_name {{rotator/x[4][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][2]} .single_bit_orig_name {rotator/x[4][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][2]/Q} .original_name {rotator/x[4][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][0]} .original_name {{rotator/y[4][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][0]} .single_bit_orig_name {rotator/y[4][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][0]/Q} .original_name {rotator/y[4][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][9]} .original_name {{rotator/x[4][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][9]} .single_bit_orig_name {rotator/x[4][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][9]/Q} .original_name {rotator/x[4][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][7]} .original_name {{rotator/x[4][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][7]} .single_bit_orig_name {rotator/x[4][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][7]/Q} .original_name {rotator/x[4][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][12]} .original_name {{rotator/x[4][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][12]} .single_bit_orig_name {rotator/x[4][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][12]/Q} .original_name {rotator/x[4][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][12]} .original_name {{rotator/y[4][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][12]} .single_bit_orig_name {rotator/y[4][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][12]/Q} .original_name {rotator/y[4][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][9]} .original_name {{rotator/y[4][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][9]} .single_bit_orig_name {rotator/y[4][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][9]/Q} .original_name {rotator/y[4][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][11]} .original_name {{rotator/y[4][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][11]} .single_bit_orig_name {rotator/y[4][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][11]/Q} .original_name {rotator/y[4][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][8]} .original_name {{rotator/x[4][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][8]} .single_bit_orig_name {rotator/x[4][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[4][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[4][8]/Q} .original_name {rotator/x[4][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][10]} .original_name {{rotator/y[4][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][10]} .single_bit_orig_name {rotator/y[4][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][10]/Q} .original_name {rotator/y[4][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][13]} .original_name {{rotator/y[4][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][13]} .single_bit_orig_name {rotator/y[4][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][13]/Q} .original_name {rotator/y[4][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][14]} .original_name {{rotator/y[4][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][14]} .single_bit_orig_name {rotator/y[4][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[4][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[4][14]/Q} .original_name {rotator/y[4][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][5]} .original_name {{rotator/ud_pipeline[5][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][5]} .single_bit_orig_name {rotator/ud_pipeline[5][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][5]/Q} .original_name {rotator/ud_pipeline[5][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][5]} .original_name {{rotator/ud_pipeline[4][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][5]} .single_bit_orig_name {rotator/ud_pipeline[4][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][5]/Q} .original_name {rotator/ud_pipeline[4][5]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][5]/QN} .original_name {rotator/ud_pipeline[4][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][5]} .original_name {{rotator/ud_pipeline[3][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][5]} .single_bit_orig_name {rotator/ud_pipeline[3][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][5]/Q} .original_name {rotator/ud_pipeline[3][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][5]} .original_name {{rotator/ud_pipeline[2][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][5]} .single_bit_orig_name {rotator/ud_pipeline[2][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][5]/Q} .original_name {rotator/ud_pipeline[2][5]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][5]/QN} .original_name {rotator/ud_pipeline[2][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][5]} .original_name {{rotator/ud_pipeline[1][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][5]} .single_bit_orig_name {rotator/ud_pipeline[1][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][5]/Q} .original_name {rotator/ud_pipeline[1][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][3]} .original_name {{rotator/y[5][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][3]} .single_bit_orig_name {rotator/y[5][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][3]/Q} .original_name {rotator/y[5][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][4]} .original_name {{rotator/x[5][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][4]} .single_bit_orig_name {rotator/x[5][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][4]/Q} .original_name {rotator/x[5][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][3]} .original_name {{rotator/x[5][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][3]} .single_bit_orig_name {rotator/x[5][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][3]/Q} .original_name {rotator/x[5][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][2]} .original_name {{rotator/x[5][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][2]} .single_bit_orig_name {rotator/x[5][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][2]/Q} .original_name {rotator/x[5][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][1]} .original_name {{rotator/y[5][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][1]} .single_bit_orig_name {rotator/y[5][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][1]/Q} .original_name {rotator/y[5][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][1]} .original_name {{rotator/x[5][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][1]} .single_bit_orig_name {rotator/x[5][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][1]/Q} .original_name {rotator/x[5][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][5]} .original_name {{rotator/x[5][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][5]} .single_bit_orig_name {rotator/x[5][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][5]/Q} .original_name {rotator/x[5][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][8]} .original_name {{rotator/y[5][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][8]} .single_bit_orig_name {rotator/y[5][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][8]/Q} .original_name {rotator/y[5][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][6]} .original_name {{rotator/x[5][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][6]} .single_bit_orig_name {rotator/x[5][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][6]/Q} .original_name {rotator/x[5][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][7]} .original_name {{rotator/x[5][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][7]} .single_bit_orig_name {rotator/x[5][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][7]/Q} .original_name {rotator/x[5][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][11]} .original_name {{rotator/x[5][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][11]} .single_bit_orig_name {rotator/x[5][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][11]/Q} .original_name {rotator/x[5][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][7]} .original_name {{rotator/y[5][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][7]} .single_bit_orig_name {rotator/y[5][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][7]/Q} .original_name {rotator/y[5][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][9]} .original_name {{rotator/y[5][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][9]} .single_bit_orig_name {rotator/y[5][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][9]/Q} .original_name {rotator/y[5][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][13]} .original_name {{rotator/x[5][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][13]} .single_bit_orig_name {rotator/x[5][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][13]/Q} .original_name {rotator/x[5][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][6]} .original_name {{rotator/y[5][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][6]} .single_bit_orig_name {rotator/y[5][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][6]/Q} .original_name {rotator/y[5][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][5]} .original_name {{rotator/ud_pipeline[0][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][5]} .single_bit_orig_name {rotator/ud_pipeline[0][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][5]/Q} .original_name {rotator/ud_pipeline[0][5]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][5]/QN} .original_name {rotator/ud_pipeline[0][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][0]} .original_name {{rotator/x[5][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][0]} .single_bit_orig_name {rotator/x[5][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][0]/Q} .original_name {rotator/x[5][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][5]} .original_name {{rotator/y[5][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][5]} .single_bit_orig_name {rotator/y[5][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][5]/Q} .original_name {rotator/y[5][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][0]} .original_name {{rotator/y[5][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][0]} .single_bit_orig_name {rotator/y[5][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][0]/Q} .original_name {rotator/y[5][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][4]} .original_name {{rotator/y[5][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][4]} .single_bit_orig_name {rotator/y[5][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][4]/Q} .original_name {rotator/y[5][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][2]} .original_name {{rotator/y[5][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][2]} .single_bit_orig_name {rotator/y[5][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][2]/Q} .original_name {rotator/y[5][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][10]} .original_name {{rotator/x[5][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][10]} .single_bit_orig_name {rotator/x[5][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][10]/Q} .original_name {rotator/x[5][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][13]} .original_name {{rotator/y[5][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][13]} .single_bit_orig_name {rotator/y[5][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][13]/Q} .original_name {rotator/y[5][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][12]} .original_name {{rotator/y[5][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][12]} .single_bit_orig_name {rotator/y[5][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][12]/Q} .original_name {rotator/y[5][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][9]} .original_name {{rotator/x[5][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][9]} .single_bit_orig_name {rotator/x[5][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][9]/Q} .original_name {rotator/x[5][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][12]} .original_name {{rotator/x[5][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][12]} .single_bit_orig_name {rotator/x[5][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][12]/Q} .original_name {rotator/x[5][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][11]} .original_name {{rotator/y[5][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][11]} .single_bit_orig_name {rotator/y[5][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][11]/Q} .original_name {rotator/y[5][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][10]} .original_name {{rotator/y[5][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][10]} .single_bit_orig_name {rotator/y[5][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][10]/Q} .original_name {rotator/y[5][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][8]} .original_name {{rotator/x[5][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][8]} .single_bit_orig_name {rotator/x[5][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][8]/Q} .original_name {rotator/x[5][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][14]} .original_name {{rotator/x[5][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][14]} .single_bit_orig_name {rotator/x[5][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[5][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[5][14]/Q} .original_name {rotator/x[5][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][14]} .original_name {{rotator/y[5][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][14]} .single_bit_orig_name {rotator/y[5][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[5][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[5][14]/Q} .original_name {rotator/y[5][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][6]} .original_name {{rotator/ud_pipeline[6][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][6]} .single_bit_orig_name {rotator/ud_pipeline[6][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][6]/Q} .original_name {rotator/ud_pipeline[6][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][6]} .original_name {{rotator/ud_pipeline[5][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][6]} .single_bit_orig_name {rotator/ud_pipeline[5][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][6]/Q} .original_name {rotator/ud_pipeline[5][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][6]} .original_name {{rotator/ud_pipeline[4][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][6]} .single_bit_orig_name {rotator/ud_pipeline[4][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][6]/Q} .original_name {rotator/ud_pipeline[4][6]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][6]/QN} .original_name {rotator/ud_pipeline[4][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][6]} .original_name {{rotator/ud_pipeline[3][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][6]} .single_bit_orig_name {rotator/ud_pipeline[3][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][6]/Q} .original_name {rotator/ud_pipeline[3][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][6]} .original_name {{rotator/ud_pipeline[2][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][6]} .single_bit_orig_name {rotator/ud_pipeline[2][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][6]/Q} .original_name {rotator/ud_pipeline[2][6]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][6]/QN} .original_name {rotator/ud_pipeline[2][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][6]} .original_name {{rotator/ud_pipeline[1][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][6]} .single_bit_orig_name {rotator/ud_pipeline[1][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][6]/Q} .original_name {rotator/ud_pipeline[1][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][2]} .original_name {{rotator/x[6][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][2]} .single_bit_orig_name {rotator/x[6][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][2]/Q} .original_name {rotator/x[6][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][4]} .original_name {{rotator/y[6][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][4]} .single_bit_orig_name {rotator/y[6][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][4]/Q} .original_name {rotator/y[6][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][6]} .original_name {{rotator/x[6][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][6]} .single_bit_orig_name {rotator/x[6][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][6]/Q} .original_name {rotator/x[6][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][5]} .original_name {{rotator/y[6][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][5]} .single_bit_orig_name {rotator/y[6][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][5]/Q} .original_name {rotator/y[6][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][5]} .original_name {{rotator/x[6][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][5]} .single_bit_orig_name {rotator/x[6][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][5]/Q} .original_name {rotator/x[6][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][4]} .original_name {{rotator/x[6][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][4]} .single_bit_orig_name {rotator/x[6][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][4]/Q} .original_name {rotator/x[6][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][3]} .original_name {{rotator/x[6][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][3]} .single_bit_orig_name {rotator/x[6][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][3]/Q} .original_name {rotator/x[6][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][6]} .original_name {{rotator/y[6][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][6]} .single_bit_orig_name {rotator/y[6][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][6]/Q} .original_name {rotator/y[6][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][0]} .original_name {{rotator/x[6][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][0]} .single_bit_orig_name {rotator/x[6][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][0]/Q} .original_name {rotator/x[6][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][1]} .original_name {{rotator/x[6][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][1]} .single_bit_orig_name {rotator/x[6][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][1]/Q} .original_name {rotator/x[6][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][7]} .original_name {{rotator/x[6][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][7]} .single_bit_orig_name {rotator/x[6][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][7]/Q} .original_name {rotator/x[6][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][13]} .original_name {{rotator/y[6][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][13]} .single_bit_orig_name {rotator/y[6][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][13]/Q} .original_name {rotator/y[6][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][14]} .original_name {{rotator/x[6][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][14]} .single_bit_orig_name {rotator/x[6][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][14]/Q} .original_name {rotator/x[6][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][11]} .original_name {{rotator/y[6][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][11]} .single_bit_orig_name {rotator/y[6][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][11]/Q} .original_name {rotator/y[6][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][7]} .original_name {{rotator/y[6][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][7]} .single_bit_orig_name {rotator/y[6][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][7]/Q} .original_name {rotator/y[6][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][6]} .original_name {{rotator/ud_pipeline[0][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][6]} .single_bit_orig_name {rotator/ud_pipeline[0][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][6]/Q} .original_name {rotator/ud_pipeline[0][6]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][6]/QN} .original_name {rotator/ud_pipeline[0][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][2]} .original_name {{rotator/y[6][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][2]} .single_bit_orig_name {rotator/y[6][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][2]/Q} .original_name {rotator/y[6][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][1]} .original_name {{rotator/y[6][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][1]} .single_bit_orig_name {rotator/y[6][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][1]/Q} .original_name {rotator/y[6][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][3]} .original_name {{rotator/y[6][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][3]} .single_bit_orig_name {rotator/y[6][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][3]/Q} .original_name {rotator/y[6][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][0]} .original_name {{rotator/y[6][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][0]} .single_bit_orig_name {rotator/y[6][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][0]/Q} .original_name {rotator/y[6][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][12]} .original_name {{rotator/y[6][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][12]} .single_bit_orig_name {rotator/y[6][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][12]/Q} .original_name {rotator/y[6][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][8]} .original_name {{rotator/x[6][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][8]} .single_bit_orig_name {rotator/x[6][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][8]/Q} .original_name {rotator/x[6][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][12]} .original_name {{rotator/x[6][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][12]} .single_bit_orig_name {rotator/x[6][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][12]/Q} .original_name {rotator/x[6][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][11]} .original_name {{rotator/x[6][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][11]} .single_bit_orig_name {rotator/x[6][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][11]/Q} .original_name {rotator/x[6][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][9]} .original_name {{rotator/y[6][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][9]} .single_bit_orig_name {rotator/y[6][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][9]/Q} .original_name {rotator/y[6][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][10]} .original_name {{rotator/y[6][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][10]} .single_bit_orig_name {rotator/y[6][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][10]/Q} .original_name {rotator/y[6][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][10]} .original_name {{rotator/x[6][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][10]} .single_bit_orig_name {rotator/x[6][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][10]/Q} .original_name {rotator/x[6][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][8]} .original_name {{rotator/y[6][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][8]} .single_bit_orig_name {rotator/y[6][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][8]/Q} .original_name {rotator/y[6][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][9]} .original_name {{rotator/x[6][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][9]} .single_bit_orig_name {rotator/x[6][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][9]/Q} .original_name {rotator/x[6][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][13]} .original_name {{rotator/x[6][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][13]} .single_bit_orig_name {rotator/x[6][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[6][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[6][13]/Q} .original_name {rotator/x[6][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][14]} .original_name {{rotator/y[6][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][14]} .single_bit_orig_name {rotator/y[6][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[6][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[6][14]/Q} .original_name {rotator/y[6][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][7]} .original_name {{rotator/ud_pipeline[7][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][7]} .single_bit_orig_name {rotator/ud_pipeline[7][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][7]/Q} .original_name {rotator/ud_pipeline[7][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][7]} .original_name {{rotator/ud_pipeline[6][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][7]} .single_bit_orig_name {rotator/ud_pipeline[6][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][7]/Q} .original_name {rotator/ud_pipeline[6][7]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][7]/QN} .original_name {rotator/ud_pipeline[6][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][7]} .original_name {{rotator/ud_pipeline[5][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][7]} .single_bit_orig_name {rotator/ud_pipeline[5][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][7]/Q} .original_name {rotator/ud_pipeline[5][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][7]} .original_name {{rotator/ud_pipeline[4][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][7]} .single_bit_orig_name {rotator/ud_pipeline[4][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][7]/Q} .original_name {rotator/ud_pipeline[4][7]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][7]/QN} .original_name {rotator/ud_pipeline[4][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][7]} .original_name {{rotator/ud_pipeline[3][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][7]} .single_bit_orig_name {rotator/ud_pipeline[3][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][7]/Q} .original_name {rotator/ud_pipeline[3][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][7]} .original_name {{rotator/ud_pipeline[2][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][7]} .single_bit_orig_name {rotator/ud_pipeline[2][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][7]/Q} .original_name {rotator/ud_pipeline[2][7]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][7]/QN} .original_name {rotator/ud_pipeline[2][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][7]} .original_name {{rotator/ud_pipeline[1][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][7]} .single_bit_orig_name {rotator/ud_pipeline[1][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][7]/Q} .original_name {rotator/ud_pipeline[1][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][6]} .original_name {{rotator/y[7][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][6]} .single_bit_orig_name {rotator/y[7][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][6]/Q} .original_name {rotator/y[7][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][2]} .original_name {{rotator/x[7][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][2]} .single_bit_orig_name {rotator/x[7][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][2]/Q} .original_name {rotator/x[7][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][1]} .original_name {{rotator/x[7][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][1]} .single_bit_orig_name {rotator/x[7][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][1]/Q} .original_name {rotator/x[7][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][1]} .original_name {{rotator/y[7][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][1]} .single_bit_orig_name {rotator/y[7][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][1]/Q} .original_name {rotator/y[7][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][0]} .original_name {{rotator/x[7][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][0]} .single_bit_orig_name {rotator/x[7][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][0]/Q} .original_name {rotator/x[7][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][7]} .original_name {{rotator/y[7][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][7]} .single_bit_orig_name {rotator/y[7][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][7]/Q} .original_name {rotator/y[7][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][2]} .original_name {{rotator/y[7][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][2]} .single_bit_orig_name {rotator/y[7][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][2]/Q} .original_name {rotator/y[7][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][6]} .original_name {{rotator/x[7][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][6]} .single_bit_orig_name {rotator/x[7][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][6]/Q} .original_name {rotator/x[7][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][5]} .original_name {{rotator/y[7][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][5]} .single_bit_orig_name {rotator/y[7][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][5]/Q} .original_name {rotator/y[7][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][4]} .original_name {{rotator/y[7][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][4]} .single_bit_orig_name {rotator/y[7][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][4]/Q} .original_name {rotator/y[7][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][3]} .original_name {{rotator/y[7][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][3]} .single_bit_orig_name {rotator/y[7][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][3]/Q} .original_name {rotator/y[7][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][13]} .original_name {{rotator/x[7][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][13]} .single_bit_orig_name {rotator/x[7][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][13]/Q} .original_name {rotator/x[7][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][11]} .original_name {{rotator/y[7][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][11]} .single_bit_orig_name {rotator/y[7][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][11]/Q} .original_name {rotator/y[7][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][13]} .original_name {{rotator/y[7][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][13]} .single_bit_orig_name {rotator/y[7][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][13]/Q} .original_name {rotator/y[7][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][14]} .original_name {{rotator/x[7][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][14]} .single_bit_orig_name {rotator/x[7][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][14]/Q} .original_name {rotator/x[7][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][3]} .original_name {{rotator/x[7][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][3]} .single_bit_orig_name {rotator/x[7][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][3]/Q} .original_name {rotator/x[7][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][0]} .original_name {{rotator/y[7][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][0]} .single_bit_orig_name {rotator/y[7][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][0]/Q} .original_name {rotator/y[7][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][4]} .original_name {{rotator/x[7][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][4]} .single_bit_orig_name {rotator/x[7][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][4]/Q} .original_name {rotator/x[7][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][5]} .original_name {{rotator/x[7][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][5]} .single_bit_orig_name {rotator/x[7][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][5]/Q} .original_name {rotator/x[7][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][7]} .original_name {{rotator/x[7][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][7]} .single_bit_orig_name {rotator/x[7][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][7]/Q} .original_name {rotator/x[7][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][7]} .original_name {{rotator/ud_pipeline[0][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][7]} .single_bit_orig_name {rotator/ud_pipeline[0][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][7]/Q} .original_name {rotator/ud_pipeline[0][7]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][7]/QN} .original_name {rotator/ud_pipeline[0][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][12]} .original_name {{rotator/y[7][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][12]} .single_bit_orig_name {rotator/y[7][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][12]/Q} .original_name {rotator/y[7][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][9]} .original_name {{rotator/x[7][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][9]} .single_bit_orig_name {rotator/x[7][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][9]/Q} .original_name {rotator/x[7][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][9]} .original_name {{rotator/y[7][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][9]} .single_bit_orig_name {rotator/y[7][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][9]/Q} .original_name {rotator/y[7][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][10]} .original_name {{rotator/x[7][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][10]} .single_bit_orig_name {rotator/x[7][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][10]/Q} .original_name {rotator/x[7][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][8]} .original_name {{rotator/y[7][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][8]} .single_bit_orig_name {rotator/y[7][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][8]/Q} .original_name {rotator/y[7][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][8]} .original_name {{rotator/x[7][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][8]} .single_bit_orig_name {rotator/x[7][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][8]/Q} .original_name {rotator/x[7][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][11]} .original_name {{rotator/x[7][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][11]} .single_bit_orig_name {rotator/x[7][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][11]/Q} .original_name {rotator/x[7][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][10]} .original_name {{rotator/y[7][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][10]} .single_bit_orig_name {rotator/y[7][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][10]/Q} .original_name {rotator/y[7][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][12]} .original_name {{rotator/x[7][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][12]} .single_bit_orig_name {rotator/x[7][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[7][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[7][12]/Q} .original_name {rotator/x[7][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][14]} .original_name {{rotator/y[7][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][14]} .single_bit_orig_name {rotator/y[7][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[7][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[7][14]/Q} .original_name {rotator/y[7][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][8]} .original_name {{rotator/ud_pipeline[8][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][8]} .single_bit_orig_name {rotator/ud_pipeline[8][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[8][8]/Q} .original_name {rotator/ud_pipeline[8][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][8]} .original_name {{rotator/ud_pipeline[7][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][8]} .single_bit_orig_name {rotator/ud_pipeline[7][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[7][8]/Q} .original_name {rotator/ud_pipeline[7][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][8]} .original_name {{rotator/ud_pipeline[6][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][8]} .single_bit_orig_name {rotator/ud_pipeline[6][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][8]/Q} .original_name {rotator/ud_pipeline[6][8]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[6][8]/QN} .original_name {rotator/ud_pipeline[6][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][8]} .original_name {{rotator/ud_pipeline[5][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][8]} .single_bit_orig_name {rotator/ud_pipeline[5][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[5][8]/Q} .original_name {rotator/ud_pipeline[5][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][8]} .original_name {{rotator/ud_pipeline[4][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][8]} .single_bit_orig_name {rotator/ud_pipeline[4][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][8]/Q} .original_name {rotator/ud_pipeline[4][8]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[4][8]/QN} .original_name {rotator/ud_pipeline[4][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][8]} .original_name {{rotator/ud_pipeline[3][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][8]} .single_bit_orig_name {rotator/ud_pipeline[3][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[3][8]/Q} .original_name {rotator/ud_pipeline[3][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][8]} .original_name {{rotator/ud_pipeline[2][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][8]} .single_bit_orig_name {rotator/ud_pipeline[2][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][8]/Q} .original_name {rotator/ud_pipeline[2][8]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[2][8]/QN} .original_name {rotator/ud_pipeline[2][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][8]} .original_name {{rotator/ud_pipeline[1][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][8]} .single_bit_orig_name {rotator/ud_pipeline[1][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[1][8]/Q} .original_name {rotator/ud_pipeline[1][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][6]} .original_name {{rotator/y[8][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][6]} .single_bit_orig_name {rotator/y[8][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][6]/Q} .original_name {rotator/y[8][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][8]} .original_name {{rotator/y[8][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][8]} .single_bit_orig_name {rotator/y[8][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][8]/Q} .original_name {rotator/y[8][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][8]} .original_name {{rotator/ud_pipeline[0][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][8]} .single_bit_orig_name {rotator/ud_pipeline[0][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][8]/Q} .original_name {rotator/ud_pipeline[0][8]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[0][8]/QN} .original_name {rotator/ud_pipeline[0][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][7]} .original_name {{rotator/y[8][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][7]} .single_bit_orig_name {rotator/y[8][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][7]/Q} .original_name {rotator/y[8][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][2]} .original_name {{rotator/y[8][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][2]} .single_bit_orig_name {rotator/y[8][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][2]/Q} .original_name {rotator/y[8][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][9]} .original_name {{rotator/y[8][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][9]} .single_bit_orig_name {rotator/y[8][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][9]/Q} .original_name {rotator/y[8][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][5]} .original_name {{rotator/y[8][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][5]} .single_bit_orig_name {rotator/y[8][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][5]/Q} .original_name {rotator/y[8][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][3]} .original_name {{rotator/y[8][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][3]} .single_bit_orig_name {rotator/y[8][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][3]/Q} .original_name {rotator/y[8][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][4]} .original_name {{rotator/y[8][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][4]} .single_bit_orig_name {rotator/y[8][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][4]/Q} .original_name {rotator/y[8][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][13]} .original_name {{rotator/x[8][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][13]} .single_bit_orig_name {rotator/x[8][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][13]/Q} .original_name {rotator/x[8][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][11]} .original_name {{rotator/x[8][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][11]} .single_bit_orig_name {rotator/x[8][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][11]/Q} .original_name {rotator/x[8][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][10]} .original_name {{rotator/y[8][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][10]} .single_bit_orig_name {rotator/y[8][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][10]/Q} .original_name {rotator/y[8][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][1]} .original_name {{rotator/y[8][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][1]} .single_bit_orig_name {rotator/y[8][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][1]/Q} .original_name {rotator/y[8][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][14]} .original_name {{rotator/y[8][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][14]} .single_bit_orig_name {rotator/y[8][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][14]/Q} .original_name {rotator/y[8][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][13]} .original_name {{rotator/y[8][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][13]} .single_bit_orig_name {rotator/y[8][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][13]/Q} .original_name {rotator/y[8][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][12]} .original_name {{rotator/y[8][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][12]} .single_bit_orig_name {rotator/y[8][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][12]/Q} .original_name {rotator/y[8][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][11]} .original_name {{rotator/y[8][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][11]} .single_bit_orig_name {rotator/y[8][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][11]/Q} .original_name {rotator/y[8][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][0]} .original_name {{rotator/y[8][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][0]} .single_bit_orig_name {rotator/y[8][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[8][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[8][0]/Q} .original_name {rotator/y[8][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][10]} .original_name {{rotator/x[8][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][10]} .single_bit_orig_name {rotator/x[8][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][10]/Q} .original_name {rotator/x[8][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][9]} .original_name {{rotator/x[8][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][9]} .single_bit_orig_name {rotator/x[8][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][9]/Q} .original_name {rotator/x[8][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][14]} .original_name {{rotator/x[8][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][14]} .single_bit_orig_name {rotator/x[8][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][14]/Q} .original_name {rotator/x[8][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][12]} .original_name {{rotator/x[8][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][12]} .single_bit_orig_name {rotator/x[8][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][12]/Q} .original_name {rotator/x[8][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[9][9]} .original_name {{rotator/ud_pipeline[9][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[9][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[9][9]} .single_bit_orig_name {rotator/ud_pipeline[9][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_ud_pipeline_reg[9][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[9][9]/Q} .original_name {rotator/ud_pipeline[9][9]/q}
set_db -quiet {pin:rope_binary_ud_pair/rotator_ud_pipeline_reg[9][9]/QN} .original_name {rotator/ud_pipeline[9][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][6]} .original_name {{rotator/x[8][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][6]} .single_bit_orig_name {rotator/x[8][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][6]/Q} .original_name {rotator/x[8][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][7]} .original_name {{rotator/x[8][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][7]} .single_bit_orig_name {rotator/x[8][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][7]/Q} .original_name {rotator/x[8][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][8]} .original_name {{rotator/x[8][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][8]} .single_bit_orig_name {rotator/x[8][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][8]/Q} .original_name {rotator/x[8][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][0]} .original_name {{rotator/x[9][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][0]} .single_bit_orig_name {rotator/x[9][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][0]/Q} .original_name {rotator/x[9][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][1]} .original_name {{rotator/x[9][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][1]} .single_bit_orig_name {rotator/x[9][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][1]/Q} .original_name {rotator/x[9][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][2]} .original_name {{rotator/x[9][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][2]} .single_bit_orig_name {rotator/x[9][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][2]/Q} .original_name {rotator/x[9][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][3]} .original_name {{rotator/x[9][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][3]} .single_bit_orig_name {rotator/x[9][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][3]/Q} .original_name {rotator/x[9][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][4]} .original_name {{rotator/x[9][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][4]} .single_bit_orig_name {rotator/x[9][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][4]/Q} .original_name {rotator/x[9][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][5]} .original_name {{rotator/x[9][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][5]} .single_bit_orig_name {rotator/x[9][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][5]/Q} .original_name {rotator/x[9][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][6]} .original_name {{rotator/x[9][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][6]} .single_bit_orig_name {rotator/x[9][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][6]/Q} .original_name {rotator/x[9][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][7]} .original_name {{rotator/x[9][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][7]} .single_bit_orig_name {rotator/x[9][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][7]/Q} .original_name {rotator/x[9][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][8]} .original_name {{rotator/x[9][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][8]} .single_bit_orig_name {rotator/x[9][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][8]/Q} .original_name {rotator/x[9][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][9]} .original_name {{rotator/x[9][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][9]} .single_bit_orig_name {rotator/x[9][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][9]/Q} .original_name {rotator/x[9][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][10]} .original_name {{rotator/x[9][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][10]} .single_bit_orig_name {rotator/x[9][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][10]/Q} .original_name {rotator/x[9][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][11]} .original_name {{rotator/x[9][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][11]} .single_bit_orig_name {rotator/x[9][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][11]/Q} .original_name {rotator/x[9][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][12]} .original_name {{rotator/x[9][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][12]} .single_bit_orig_name {rotator/x[9][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][12]/Q} .original_name {rotator/x[9][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][13]} .original_name {{rotator/x[9][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][13]} .single_bit_orig_name {rotator/x[9][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][13]/Q} .original_name {rotator/x[9][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][14]} .original_name {{rotator/x[9][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][14]} .single_bit_orig_name {rotator/x[9][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[9][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[9][14]/Q} .original_name {rotator/x[9][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][0]} .original_name {{rotator/x[10][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][0]} .single_bit_orig_name {rotator/x[10][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][0]/Q} .original_name {rotator/x[10][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][1]} .original_name {{rotator/x[10][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][1]} .single_bit_orig_name {rotator/x[10][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][1]/Q} .original_name {rotator/x[10][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][2]} .original_name {{rotator/x[10][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][2]} .single_bit_orig_name {rotator/x[10][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][2]/Q} .original_name {rotator/x[10][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][3]} .original_name {{rotator/x[10][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][3]} .single_bit_orig_name {rotator/x[10][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][3]/Q} .original_name {rotator/x[10][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][4]} .original_name {{rotator/x[10][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][4]} .single_bit_orig_name {rotator/x[10][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][4]/Q} .original_name {rotator/x[10][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][5]} .original_name {{rotator/x[10][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][5]} .single_bit_orig_name {rotator/x[10][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][5]/Q} .original_name {rotator/x[10][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][6]} .original_name {{rotator/x[10][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][6]} .single_bit_orig_name {rotator/x[10][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][6]/Q} .original_name {rotator/x[10][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][7]} .original_name {{rotator/x[10][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][7]} .single_bit_orig_name {rotator/x[10][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][7]/Q} .original_name {rotator/x[10][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][5]} .original_name {{rotator/x[8][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][5]} .single_bit_orig_name {rotator/x[8][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][5]/Q} .original_name {rotator/x[8][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][9]} .original_name {{rotator/x[10][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][9]} .single_bit_orig_name {rotator/x[10][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][9]/Q} .original_name {rotator/x[10][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][10]} .original_name {{rotator/x[10][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][10]} .single_bit_orig_name {rotator/x[10][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][10]/Q} .original_name {rotator/x[10][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][11]} .original_name {{rotator/x[10][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][11]} .single_bit_orig_name {rotator/x[10][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][11]/Q} .original_name {rotator/x[10][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][12]} .original_name {{rotator/x[10][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][12]} .single_bit_orig_name {rotator/x[10][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][12]/Q} .original_name {rotator/x[10][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][13]} .original_name {{rotator/x[10][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][13]} .single_bit_orig_name {rotator/x[10][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][13]/Q} .original_name {rotator/x[10][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][0]} .original_name {{rotator/x[8][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][0]} .single_bit_orig_name {rotator/x[8][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][0]/Q} .original_name {rotator/x[8][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][14]} .original_name {{rotator/x[10][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][14]} .single_bit_orig_name {rotator/x[10][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][14]/Q} .original_name {rotator/x[10][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][0]} .original_name {{rotator/y[9][0]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][0]} .single_bit_orig_name {rotator/y[9][0]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][0]/Q} .original_name {rotator/y[9][0]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][1]} .original_name {{rotator/y[9][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][1]} .single_bit_orig_name {rotator/y[9][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][1]/Q} .original_name {rotator/y[9][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][2]} .original_name {{rotator/y[9][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][2]} .single_bit_orig_name {rotator/y[9][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][2]/Q} .original_name {rotator/y[9][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][3]} .original_name {{rotator/y[9][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][3]} .single_bit_orig_name {rotator/y[9][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][3]/Q} .original_name {rotator/y[9][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][4]} .original_name {{rotator/y[9][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][4]} .single_bit_orig_name {rotator/y[9][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][4]/Q} .original_name {rotator/y[9][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][5]} .original_name {{rotator/y[9][5]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][5]} .single_bit_orig_name {rotator/y[9][5]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][5]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][5]/Q} .original_name {rotator/y[9][5]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][6]} .original_name {{rotator/y[9][6]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][6]} .single_bit_orig_name {rotator/y[9][6]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][6]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][6]/Q} .original_name {rotator/y[9][6]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][7]} .original_name {{rotator/y[9][7]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][7]} .single_bit_orig_name {rotator/y[9][7]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][7]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][7]/Q} .original_name {rotator/y[9][7]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][8]} .original_name {{rotator/y[9][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][8]} .single_bit_orig_name {rotator/y[9][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][8]/Q} .original_name {rotator/y[9][8]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][9]} .original_name {{rotator/y[9][9]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][9]} .single_bit_orig_name {rotator/y[9][9]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][9]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][9]/Q} .original_name {rotator/y[9][9]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][10]} .original_name {{rotator/y[9][10]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][10]} .single_bit_orig_name {rotator/y[9][10]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][10]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][10]/Q} .original_name {rotator/y[9][10]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][11]} .original_name {{rotator/y[9][11]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][11]} .single_bit_orig_name {rotator/y[9][11]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][11]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][11]/Q} .original_name {rotator/y[9][11]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][12]} .original_name {{rotator/y[9][12]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][12]} .single_bit_orig_name {rotator/y[9][12]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][12]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][12]/Q} .original_name {rotator/y[9][12]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][13]} .original_name {{rotator/y[9][13]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][13]} .single_bit_orig_name {rotator/y[9][13]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][13]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][13]/Q} .original_name {rotator/y[9][13]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][14]} .original_name {{rotator/y[9][14]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][14]} .single_bit_orig_name {rotator/y[9][14]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_y_reg[9][14]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_y_reg[9][14]/Q} .original_name {rotator/y[9][14]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][1]} .original_name {{rotator/x[8][1]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][1]} .single_bit_orig_name {rotator/x[8][1]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][1]/Q} .original_name {rotator/x[8][1]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][2]} .original_name {{rotator/x[8][2]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][2]} .single_bit_orig_name {rotator/x[8][2]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][2]/Q} .original_name {rotator/x[8][2]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][3]} .original_name {{rotator/x[8][3]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][3]} .single_bit_orig_name {rotator/x[8][3]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][3]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][3]/Q} .original_name {rotator/x[8][3]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][4]} .original_name {{rotator/x[8][4]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][4]} .single_bit_orig_name {rotator/x[8][4]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[8][4]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[8][4]/Q} .original_name {rotator/x[8][4]/q}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][8]} .original_name {{rotator/x[10][8]}}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][8]} .single_bit_orig_name {rotator/x[10][8]}
set_db -quiet {inst:rope_binary_ud_pair/rotator_x_reg[10][8]} .gint_phase_inversion false
set_db -quiet {pin:rope_binary_ud_pair/rotator_x_reg[10][8]/Q} .original_name {rotator/x[10][8]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.10-p002_1
## flowkit v21.10-d047_1
## Written on 18:56:36 22-Apr 2026
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid 9d90a343-9dbf-40d8-ba0c-d7745e464bbb}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_reset_time_after_flow_init -obj_type root]} {set_db flow_reset_time_after_flow_init false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_yamllint_exec -obj_type root]} {set_db flow_yamllint_exec yamllint}

#############################################################
#####   User Defined Attributes   ###########################

